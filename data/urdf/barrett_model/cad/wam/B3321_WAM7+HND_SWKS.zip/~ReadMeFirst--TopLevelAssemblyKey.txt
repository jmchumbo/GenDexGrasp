Please use key below to determine your top-level assembly of interest.

B2731 4-axis WAM arm
B3435 4-axis WAM arm with BarrettHand
B3320 7-axis WAM arm
B3321 7-axis WAM arm with BarrettHand
B2579 BarrettHand
B1314 WAM workspace
B2646 4-axis WAM arm with 3-axis rehabilitation gimbals

These associated Barrett assemblies and parts are current as of 22-July-2007.

Please contact support@barrett.com if you have trouble with these files or if you cannot find the format that you need.

Comments:
1.  Native files were created in SolidWorks.
2.  Translations may have broken mates.  (small black squares showing up near the Hand model are likely only finger labels that can be safely deleted.
3.  Coordinate frames with associated curved arrows may be deleted or hidden/supressed as desired.
4.  The workspace may be hidden/supressed as desired.